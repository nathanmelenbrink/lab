%-----------------    GROPT.m   -----------------------------------
% This program is used for simulating a car traveling at different 
% transmissio ratios, in order to select optimal ratio for the 2.007
% class students at MIT.

% Last Modified 01/18/2004 by Jian_Li@MIT 
% Last modified 12/04/2004 by Jian_Li@Applied Materials



function varargout = GROpt(varargin)

if nargin == 0  % LAUNCH GUI

	fig = openfig(mfilename,'reuse');

	% Generate a structure of handles to pass to callbacks, and store it. 
	handles = guihandles(fig);
	guidata(fig, handles);

	if nargout > 0
		varargout{1} = fig;
	end

elseif ischar(varargin{1}) % INVOKE NAMED SUBFUNCTION OR CALLBACK

	try
		[varargout{1:nargout}] = feval(varargin{:}); % FEVAL switchyard
	catch
		disp(lasterr);
	end

end

%%--------------------------------------------------------------------

% Radio buttons on selecting different transmission ratios

% --------------------------------------------------------------------
function varargout = GearRatio1_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.radiobutton1.
set(handles.GearRatio1, 'value', 1)
set(handles.GearRatio2, 'value', 0)
set(handles.GearRatio3, 'value', 0)
set(handles.GearRatio4, 'value', 0)
set(handles.GearRatio5, 'value', 0)
set(handles.GearRatio6, 'value', 0)

function varargout = GearRatio2_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.GearRatio2.
set(handles.GearRatio1, 'value', 0)
set(handles.GearRatio2, 'value', 1)
set(handles.GearRatio3, 'value', 0)
set(handles.GearRatio4, 'value', 0)
set(handles.GearRatio5, 'value', 0)
set(handles.GearRatio6, 'value', 0)

function varargout = GearRatio3_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.GearRatio2.
set(handles.GearRatio1, 'value', 0)
set(handles.GearRatio2, 'value', 0)
set(handles.GearRatio3, 'value', 1)
set(handles.GearRatio4, 'value', 0)
set(handles.GearRatio5, 'value', 0)
set(handles.GearRatio6, 'value', 0)

function varargout = GearRatio4_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.GearRatio2.
set(handles.GearRatio1, 'value', 0)
set(handles.GearRatio2, 'value', 0)
set(handles.GearRatio3, 'value', 0)
set(handles.GearRatio4, 'value', 1)
set(handles.GearRatio5, 'value', 0)
set(handles.GearRatio6, 'value', 0)

function varargout = GearRatio5_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.GearRatio2.
set(handles.GearRatio1, 'value', 0)
set(handles.GearRatio2, 'value', 0)
set(handles.GearRatio3, 'value', 0)
set(handles.GearRatio4, 'value', 0)
set(handles.GearRatio5, 'value', 1)
set(handles.GearRatio6, 'value', 0)

function varargout = GearRatio6_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.GearRatio2.
set(handles.GearRatio1, 'value', 0)
set(handles.GearRatio2, 'value', 0)
set(handles.GearRatio3, 'value', 0)
set(handles.GearRatio4, 'value', 0)
set(handles.GearRatio5, 'value', 0)
set(handles.GearRatio6, 'value', 1)


% --------------------------------------------------------------------


% ------------------------------------------------------------------
function varargout = cmd_OK_Callback(h, eventdata, handles, varargin, GearRatio)
% Stub for Callback of the uicontrol handles.cmd_OK.

g=9.8; %gravity acc.

GearRatio=get(handles.GearRatio1,'value');
if GearRatio==1
    GearRatio=1;
    nTrans=16;
    nStage=2;
else
    GearRatio=get(handles.GearRatio2,'value');
    if GearRatio==1
        GearRatio=2;
        nTrans=20;
        nStage=2;
    else
        GearRatio=get(handles.GearRatio3,'value');
        if GearRatio==1
            GearRatio=3;
            nTrans=25;
            nStage=3;
        else
           GearRatio=get(handles.GearRatio4,'value');
            if GearRatio==1
                GearRatio=4;
                nTrans=80;
                nStage=3;
            else
                GearRatio=get(handles.GearRatio5,'value');
                if GearRatio==1;
                    GearRatio=5;
                    nTrans=100;
                    nStage=3;
                else
                    GearRatio=get(handles.GearRatio6,'value');
                    if GearRatio==1;
                        GearRatio=6;
                        nTrans=400;
                        nStage=4;
                    else
                        errordlg('Invalid Gear Ratio Selection','Error');
                        return;
                    end
                end                
            end
       end
   end
end

OGr1=get(handles.txtOGr1, 'string'); %secondary transmission ratio
OGr1=str2num(OGr1);

if OGr1<=0
    errordlg('Invalid Outside Gear Ratio','Error')
    return;
end

OGr2=get(handles.txtOGr2, 'string');
OGr2=str2num(OGr2);
if OGr2<=0
    errordlg('Invalid Outside Gear Ratio','Error')
    return;
end

OGr=OGr1/OGr2;

nWheels=get(handles.txtnWheels, 'string'); %number of wheels
nWheels=str2num(nWheels);
if nWheels<=0
    errordlg('Invalid Number of Wheels','Error')
    return;
end

nDWheels=get(handles.txtnDWheels, 'string'); %number of driving wheels
nDWheels=str2num(nDWheels);
if nDWheels<=0
    errordlg('Invalid Number of Driving Wheels','Error')
    return;
end

if nDWheels>nWheels
    errordlg('The driving wheels more than the wheels','Error');
    return;
end


nDMotors=get(handles.txtnDMotors, 'string'); %number of motors
nDMotors=str2num(nDMotors);
if nDMotors<=0
    errordlg('Invalid Number of Driving Motors','Error')
    return;
end


JWheel=get(handles.txtJWheel,'string'); %rotational moment of inertial of one wheel
JWheel=str2num(JWheel);
if JWheel<=0
    errordlg('Invalid Rotational Momentum of Inertia','Error')
    return;
end


mCar=get(handles.txtmCar,'string'); %car mass
mCar=str2num(mCar);
if mCar<=0 | mCar>=20
    errordlg('Invalid Mass of Car','Error')
    return;
end


rWheel=get(handles.txtrWheel,'string'); %wheel radius
rWheel=str2num(rWheel);
if rWheel<=0
    errordlg('Invalid Wheel Radius','Error')
    return;
end

%rsFriction=get(handles.txtrsFriction,'string');
%rsFriction=str2num(rsFriction);
%if rsFriction<=0
%    errordlg('Invalid Rolling Static Friction Coefficient','Error')
%    break;
%end

rkFriction=get(handles.txtrkFriction,'string');  %dynamic friction efficiency
rkFriction=str2num(rkFriction);
if rkFriction<=0
    errordlg('Invalid Rolling Kinetic Friction Coefficient','Error')
    return;
end;


ssFriction=get(handles.txtssFriction,'string');  %static friction efficiency
ssFriction=str2num(ssFriction);
if ssFriction<=0
    errordlg('Invalid Sliding Static Friction Coefficient','Error')
    return;
end


pForce=get(handles.txtpForce,'string'); %push force F_push
pForce=str2num(pForce);
if pForce<0
    errordlg('Invalid Push Force','Error')
    return;
end


dsrdCar=get(handles.txtDistance, 'string'); %desired car travel distance
dsrdCar=str2num(dsrdCar);
if dsrdCar<=0
    errordlg('Invalid Desired Distance','Error')
    return;
end


eff=get(handles.txtEff, 'string'); %drive train efficiency
eff=str2num(eff);
if eff<=0
    errordlg('Invalid drive train efficiency','Error')
    return;
end


Resist=get(handles.txtResist, 'string'); %motor winding resistance
Resist=str2num(Resist);
if eff<=0
    errordlg('Invalid Resistance','Error')
    return;
end

%%--------------- load the look-up table data ---------------%
switch GearRatio
case 1
    TSData=load('TS1_16.txt');
case 2
    TSData=load('TS1_20.txt'); 
case 3
    TSData=load('TS1_25.txt');
case 4 
    TSData=load('TS1_80.txt');
case 5
    TSData=load('TS1_100.txt');
case 6
    TSData=load('TS1_400.txt');
end    

if TSData==0
    errordlg('File not loaded','Error')
    return;
end

TblSpeed=TSData(:,1)*OGr; %Speed data look-up table
TblTorque=eff*nDMotors/OGr*TSData(:,2); %Torque data look-up table
TblCurrent=TSData(:,3); % current data
TblVolt=TSData(:,4); %voltage data
TblEff=TSData(:,5); %motor efficiency data

%------------------- Moment inertia calculations ------------------%
JCar=mCar*rWheel^2;  %equivalent car rotational moment inertia
JWheels=nWheels*JWheel; %moment inertia for all wheels
JMotor=5.63e-7; %rotational moment inertia of the motor rotor
JChain=3.94e-7; %rotational moment inertia of the drive train
JTrans=(JMotor+JChain*nStage); %transmission rotational moment inertia

JAll=JCar+JWheels+JTrans*nTrans^2; %all...

%-------------------------------------------------------------------%%

%----------- time incremental step --------------------------------%%
if dsrdCar<=0.1
    tStep=0.003; %3ms
else
    tStep=0.005; %5mS
end
%------------------------------------------------------------------%

i=1;
t(i)=0; %time, starts from 0s
AngSpWheel(i)=0; %Initial Wheel Angle Speed
Torque(i)=max(TblTorque); %Initial Torque
AngAccWheel(i)=(Torque(i)-rkFriction*mCar*g*rWheel-pForce*rWheel)/JAll; %Initial Angle Acceleration
%Power(i)= TblCurrent(i)^2*Resist/TblEff(i); %Power of the motor
Power(i)=TblCurrent(i)*TblVolt(i); %Power of the motor = Umotor*Imotor(i)
Energy(i)=0; %Energy consumed of the motor
pkPwr=Power(i); %peak power
dCar(i)=0; %Initial Car Distance

if Torque(i)>ssFriction*mCar*g*nDWheels/nWheels*rWheel %static friction
    errordlg('Car sliding!','Error')
    return;
elseif Torque(i)-rkFriction*mCar*g*rWheel-pForce*rWheel<0.01
    errordlg('Not enough torque to drive the car! Please change your inputs','Error')
    return
end

%------------- Acceleration --------------%

while AngAccWheel(i)>0.01 & dCar(i)<dsrdCar
    i=i+1;
    t(i)=t(i-1)+tStep;
    AngSpWheel(i)=AngSpWheel(i-1)+AngAccWheel(i-1)*tStep;
    vCar(i)=AngSpWheel(i)*rWheel;
    dCar(i)=dCar(i-1)+vCar(i)*tStep;
    Torque(i)=interp1(TblSpeed, TblTorque, AngSpWheel(i));
    AngAccWheel(i)= (Torque(i)-rkFriction*mCar*g*rWheel-pForce*rWheel)/JAll;
    
    Current(i)=interp1(TblSpeed, TblCurrent, AngSpWheel(i));
    Voltage(i)=interp1(TblSpeed, TblVolt, AngSpWheel(i));
    Efficiency(i)=interp1(TblSpeed, TblEff, AngSpWheel(i));
    %Power(i)= Current(i)^2*Resist/Efficiency(i); %Power of the motor
    Power(i)=Current(i)*Voltage(i); %Power of the motor = Umotor*Imotor(i)
    
    Energy(i)=Energy(i-1)+Power(i)*tStep;
    
    if pkPwr < Power(i)
        pkPwr=Power(i);
    end
        
end

tmAcc=t(i);
vmaxCar=vCar(i); %The maximum velocity of the car
AngSpmax=AngSpWheel(i); %The maximum angular velocity of the car;
dCarAcc=dCar(i); %Distance during acceleration

stepVmax=i; %The time step at max velocity

%%%Save the data to a look-up table (array)

TblVAcc=vCar;
TblDAcc=dCar;
TblTAcc=t;
TblEAcc=Energy;
TblPAcc=Power;

%-----------------------------------------%




%-----------  Deceleration ---------------%
tmDcl=0;
AngDclWheel(i)=(Torque(i)+rkFriction*mCar*g*rWheel+pForce*rWheel)/JAll;

while AngSpWheel(i)>0.01
    i=i+1;
    t(i)=t(i-1)+tStep;
    AngSpWheel(i)=AngSpWheel(i-1)-AngDclWheel(i-1)*tStep;
    vCar(i)=AngSpWheel(i)*rWheel;
    dCar(i)=dCar(i-1)+vCar(i)*tStep;
    Torque(i)=-interp1(TblSpeed, TblTorque, AngSpWheel(i));
    AngDclWheel(i)=(-Torque(i)+rkFriction*mCar*g*rWheel+pForce*rWheel)/JAll;

    Current(i)=interp1(TblSpeed, TblCurrent, AngSpWheel(i));
    Voltage(i)=interp1(TblSpeed, TblVolt, AngSpWheel(i));
    Efficiency(i)=interp1(TblSpeed, TblEff, AngSpWheel(i));
    
    Power(i)= 0; %Power of the motor
    Energy(i)=Energy(i-1);
end

dCarDcl=dCar(i)-dCarAcc; %car traveling distance during deceleration period.
tmDcl=t(i)-tmAcc;

overallSteps=i; %overall time steps during the whole 3 periods.
overalldCar=dCar(i); %total distance if the car is accelerated to full speed then decelerate to 0.
overallTime=t(i);%overall time during the whole 3 periods.

TblVDcl=vCar(stepVmax:overallSteps); %look-up table during deceleration period
TblDDcl=dCar(stepVmax:overallSteps);
TblTDcl=t(stepVmax:overallSteps);
TblEDcl=Energy(stepVmax:overallSteps);
TblPDcl=Power(stepVmax:overallSteps);

%--------------------------------------------%



%--------------- Any Constant speed time?-------------------%

if overalldCar-dsrdCar<0 %there is constant speed time
    
    %---------- Constant speed time -----------%
    tmConstSpd=(dsrdCar-overalldCar)/vmaxCar;
    EnConstSpd=Power(stepVmax)*tmConstSpd;
    
    for j=stepVmax:1:overallSteps
        
        t(j)=t(j)+tmConstSpd; %shift in time by const speed time
        dCar(j)=dCar(j)+dsrdCar-overalldCar; %plug in the distance on constant speed
        Energy(j)=Energy(j)+EnConstSpd;
        
    end 
 
    tPlot=t;
    dCarPlot=dCar; %distance to be plotted
    vCarPlot=vCar; %velocity to be plotted
    EnergyPlot=Energy;
    TorquePlot=Torque;
    TorquePlot(stepVmax)=TorquePlot(stepVmax-1);
    
    ttlTime=t(j); %Total time including the constant speed time
    
    ttlEng=Energy(overallSteps); %total consumed energy
    %----------------------------------------------%
    
    
else if overalldCar-dsrdCar>=0 %the total distance is larger than desired distance.
      
      tmConstSpd=0;
      
      %---------------- Cut the top -----------------%  
      v=vmaxCar;    
      ttldCar=overalldCar;
        
      while ttldCar-dsrdCar>0.01 %decrease the maximum speed until the total distance equals desired distance
            
            v = v-0.005; %decrease maximum speed
            
            dCarAcc=interp1(TblVAcc, TblDAcc, v); %find out the distance during acceleration 0->v
            
            dCarDcl=overalldCar-interp1(TblVDcl, TblDDcl, v); %distance during deceleration  v->0
                    
            ttldCar=dCarAcc+dCarDcl;
                                        
        end
        
        vAcc=interp1(TblDAcc, TblVAcc, dCarAcc);
        vDcl=interp1(TblDDcl, TblVDcl, overalldCar-dCarDcl);
        
        
        tmAccEnd=interp1(TblVAcc, TblTAcc, v); %the time at v
        tmAccEndStep=round(tmAccEnd/tStep);%time step
        tmAccEnd=tmAccEndStep*tStep;%recalculate to fit the time step
        tmAcc=tmAccEnd-0;
        
        tmDclStart=interp1(TblVDcl, TblTDcl, v); %time at v
        tmDclStartStep=round(tmDclStart/tStep); 
        tmDclStart=tmDclStartStep*tStep; %recalculate
        tmDcl=overallTime-tmDclStart; %ttlTime is tacc+tdcl with Vmaximum      
        
        ttlTime=tmAcc+tmDcl; %total time of tacc+tdcl at v (not vmaximum)
        ttlSteps=round(ttlTime/tStep);
        
        tPlot=t(1:ttlSteps);
        dCarPlot(1:tmAccEndStep)=dCar(1:tmAccEndStep);
        vCarPlot(1:tmAccEndStep)=vCar(1:tmAccEndStep);
        EnergyPlot(1:tmAccEndStep)=Energy(1:tmAccEndStep);
        TorquePlot(1:tmAccEndStep)=Torque(1:tmAccEndStep);

        dCarPlot(tmAccEndStep+1:ttlSteps)= dCar(tmDclStartStep:ttlSteps-tmAccEndStep-1+tmDclStartStep)-(dCar(tmDclStartStep+1)-dCar(tmAccEndStep)); %Substract the displacement
        vCarPlot(tmAccEndStep+1:ttlSteps)= vCar(tmDclStartStep:ttlSteps-tmAccEndStep-1+tmDclStartStep);
        EnergyPlot(tmAccEndStep+1:ttlSteps)=Energy(tmAccEndStep); %No energy consumed after peak point        
        TorquePlot(tmAccEndStep+1:ttlSteps)= Torque(tmDclStartStep:ttlSteps-tmAccEndStep-1+tmDclStartStep);
         
        ttlEng=EnergyPlot(ttlSteps); %total consumed energy
    end

end
    

set(handles.txtAccTime, 'string', tmAcc);
set(handles.txtConsSpdTime, 'string', tmConstSpd);
set(handles.txtDclTime, 'string', tmDcl);
set(handles.txtTtlTime, 'string', ttlTime);
set(handles.txtPkPwr, 'string', pkPwr);
set(handles.txtTtlEng, 'string', ttlEng)


%-------------- Estimations --------------------%

Gamamax=max(TblTorque)-rkFriction*mCar*g*rWheel-pForce*rWheel;
s=-Gamamax/max(TblSpeed);

for m=1:1:round(100*max(tPlot)) %100 points
    tEst(m)=m/100;
    xEst(m)=rWheel*(JAll*Gamamax/s^2*exp(s*tEst(m)/JAll)-Gamamax/s*tEst(m)-JAll*Gamamax/s^2);
end
   


%%--------------------  Plots ------------------%%

figure;
subplot(2,2,1), plot(vCarPlot, TorquePlot/eff, 'r', 'LineWidth',3);
xlabel('Speed [m/s]')
ylabel('Total Torque [Nm]')
title('Plot of Overall Torque vs. Time')
grid on;
subplot(2,2,2), plot(tPlot, vCarPlot, 'r', 'LineWidth',3);
xlabel('Time [s]')
ylabel('Speed [m/s]')
title('Plot of Speed vs. Time')
grid on;
subplot(2,2,3), plot(tPlot, dCarPlot,'LineWidth',3);
xlabel('Time [s]')
ylabel('Distance [m]')
title('Plot of Distance vs. Time')
grid on;
hold on;
subplot(2,2,3), plot(tEst, xEst, 'm', 'LineWidth', 2);

subplot(2,2,4), plot(tPlot, EnergyPlot,'LineWidth',3);
xlabel('Time [s]')
ylabel('Energy [J]')
title('Plot of Energy vs. Time')
grid on;
save b.mat;

%%%------------- End --------------------------------%%

